<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\TemplateEmail;

use Auth;

use App\Http\Requests;

class TemplateEmailController extends Controller
{
    //

    public function index(){

    	$data['title'] = "";
    	$data['header'] = "";
    	$data['deskripsi'] = "";
    	return view("backend/mail/template_email",$data);
    }

    public function getTemplateEmail(){
    	$get = new TemplateEmail;
    	$data = $get::orderBy('created_at','Desc')->get();

    	$array = array();
    	foreach ($data as $row) {
    		$arr = array();
    		$arr[] = $row->isi;
    		// if($row->status == 1){
    		// 	$arr[] = "<span class='badge'>Aktif</span>";	
    		// }else{
    		// 	$arr[] = "<span class='badge'>Tidak Aktif</span>";	
    		// }
    		$arr[] = $row->created_at->format('Y-m-d h:i:s');
    		if(Auth::user()->rule_id == 1 ){
    		 $arr[] = "<a href='javascript::' onclick='hapus(".$row->id.")' class='btn btn-danger'><i class='fa fa-trash'></i></a> <a href='#viewModal' data-toggle='modal' data-target='#viewModal' data-whatever=".$row->id." class='btn btn-default'><i class='fa fa-search'></i></a>";
    		}else{
    			$arr[] = "<a href='#viewModal' data-toggle='modal' data-target='#viewModal' data-whatever=".$row->id." class='btn btn-default'><i class='fa fa-search'></i></a>";
    		}
    	
    		$array[] = $arr;
    	}

    	$output = array("data" => $array);

    	return json_encode($output);
    }

    public function delete(){
    	$id = $_GET['id'];
    	$find = new TemplateEmail;
    	$find::destroy("id",$id);
    }

    public function store(Request $request){
    	$email = new TemplateEmail;
    	//$email->subject = $request->subject;
    	$email->isi = $request->isi;
    	//$email->view_template = $request->view_template;
    	$email->save();

    	$request->session()->flash('pesan', "Template email berhasil ditambahkan");
    	return redirect("backend/template-email");

    }

    
}
