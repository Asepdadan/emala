<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DashboardController extends Controller
{
    //

    public function index(){
    	$data["title"] = "Dashboard";
    	$data["header"] = "Dashboard";
    	$data["deskripsi"] = "Dashboard E-MALA";

    	return view("backend.dashboard.dashboard",$data);

    }
}
