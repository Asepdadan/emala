<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;

class PelatihanController extends Controller
{
    //

    public function aksiPelatihanRekanan(Request $request){
    	//dd($request->all());
    	$input = $request->all();
    	DB::table('pelatihan')->insert(
		    ['nama' => $input["nama"] , 
		    "id_pelatihan" => 1,
		    "nama_perusahaan" => $input["nama_perusahaan"],
		    "alamat" => $input["alamat"],
		    "no_hp" => $input["no_hp"],
		    "email" => $input["email"],
		    "tanggal_pelatihan" => $input["tanggal_pelatihan"]
		    ]
		);

    	$request->session()->flash('pesan', "FORMULIR PENDAFTARAN PELATIHAN BAGI PENYEDIA/REKANAN berhasil di ajukan");
    	return redirect("formulir-rekanan");
    }

    public function getDataPenyedia(){
	$json= DB::table('pelatihan')->get();
	
	$array = array();
	$no = 1;
	foreach ($json as $row) {
		$arr = array();
		$arr[] = $no++;
		$arr[] = $row->nama;
		$arr[] = $row->nama_perusahaan;
		$arr[] = $row->alamat;
		$arr[] = $row->tanggal_pelatihan;
		$array[] = $arr;
	}

	$output = array(
            "data" => $array
        );
    return json_encode($output);
    }
}
