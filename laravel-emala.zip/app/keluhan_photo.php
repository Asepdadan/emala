<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class keluhan_photo extends Model
{
    //
}
