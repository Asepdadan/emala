<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tentang_kami extends Model
{
    //
}
