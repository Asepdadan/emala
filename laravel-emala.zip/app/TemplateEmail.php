<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TemplateEmail extends Model
{
    //

    protected $table = "template_emails";
}
