<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Buku_tamu extends Model
{
    //
    protected $table = "daftar_tamu";
}
